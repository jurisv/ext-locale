describe('Ext.chart.legend.LegendBase', function() {
    it('is defined', function() {
        expect(Ext.chart.legend.LegendBase).toBeDefined();
    });
});
