Ext.define('Ext.draw.overrides.hittest.All', {
    requires: [
        'Ext.draw.PathUtil',
        'Ext.draw.overrides.hittest.sprite.Instancing',
        'Ext.draw.overrides.hittest.Surface'
    ]
});
