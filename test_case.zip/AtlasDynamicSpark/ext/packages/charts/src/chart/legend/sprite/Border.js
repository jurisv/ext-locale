/**
 * @private
 */
Ext.define('Ext.chart.legend.sprite.Border', {
    extend: 'Ext.draw.sprite.Rect',
    alias: 'sprite.legendborder',
    type: 'legendborder',
    isLegendBorder: true
});
