# calendar/sass

This folder contains SASS files of various kinds, organized in sub-folders:

    calendar/sass/etc
    calendar/sass/src
    calendar/sass/var
